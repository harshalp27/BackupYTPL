package com.yash.rrf.dao;

import com.yash.rrf.model.*;


public interface AddResourceDao {

	public ResourceDetails saveResourceDetails(ResourceDetails resourceDetails);
	
}
